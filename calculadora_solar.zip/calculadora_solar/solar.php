<?php
require 'conexao.php'; //Puxar informações da conexao

?>